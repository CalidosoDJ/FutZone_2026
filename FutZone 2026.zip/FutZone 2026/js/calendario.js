// ===============================
// REFERENCIAS DOM
// ===============================

const selectYear = document.getElementById("select-year");
const selectMonth = document.getElementById("select-month");
const diasMes = document.getElementById("dias-mes");
const horasDisponibles = document.getElementById("horas-disponibles");
const canchasDisponibles = document.getElementById("canchas-disponibles");

let fechaSeleccionada = null;
let horaSeleccionada = null;


// ===============================
// DATOS SIMULADOS
// ===============================

const horasPorDia = [
    "08:00 - 09:00",
    "09:00 - 10:00",
    "10:00 - 11:00",
    "11:00 - 12:00",
    "12:00 - 13:00",
    "13:00 - 14:00",
    "14:00 - 15:00",
    "15:00 - 16:00",
    "16:00 - 17:00"
];

const todasLasCanchas = [
    "Cancha 1",
    "Cancha 2",
    "Cancha 3",
    "Cancha 4"
];

// Reservas simuladas
const reservas = [
    { fecha: "2026-2-24", hora: "08:00 - 09:00", cancha: "Cancha 1" },
    { fecha: "2026-2-24", hora: "08:00 - 09:00", cancha: "Cancha 2" }
];


// ===============================
// LLENAR AÑOS
// ===============================

function llenarAnios() {
    const anioActual = new Date().getFullYear();
    for (let i = anioActual; i <= anioActual + 5; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = i;
        selectYear.appendChild(option);
    }
}


// ===============================
// LLENAR MESES
// ===============================

function llenarMeses() {
    const meses = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];

    meses.forEach((mes, index) => {
        const option = document.createElement("option");
        option.value = index;
        option.textContent = mes;
        selectMonth.appendChild(option);
    });
}


// ===============================
// GENERAR CALENDARIO
// ===============================

function generarCalendario(anio, mes) {

    diasMes.innerHTML = "";
    horasDisponibles.innerHTML = "";
    canchasDisponibles.innerHTML = "";

    const primerDia = new Date(anio, mes, 1).getDay();
    const diasEnMes = new Date(anio, mes + 1, 0).getDate();

    let fila = document.createElement("tr");

    let inicio = primerDia === 0 ? 6 : primerDia - 1;

    for (let i = 0; i < inicio; i++) {
        const celda = document.createElement("td");
        fila.appendChild(celda);
    }

    for (let dia = 1; dia <= diasEnMes; dia++) {

        if (fila.children.length === 7) {
            diasMes.appendChild(fila);
            fila = document.createElement("tr");
        }

        const celda = document.createElement("td");
        celda.textContent = dia;
        celda.classList.add("cursor-pointer");

        celda.addEventListener("click", () => {

            fechaSeleccionada = `${anio}-${mes + 1}-${dia}`;

            document.querySelectorAll("#dias-mes td")
                .forEach(td => td.classList.remove("table-primary"));

            celda.classList.add("table-primary");

            mostrarHoras();
        });

        fila.appendChild(celda);
    }

    while (fila.children.length < 7) {
        const celda = document.createElement("td");
        fila.appendChild(celda);
    }

    diasMes.appendChild(fila);
}


// MOSTRAR HORAS

function mostrarHoras() {

    horasDisponibles.innerHTML = "";
    canchasDisponibles.innerHTML = "";
    horaSeleccionada = null;

    horasPorDia.forEach((hora, index) => {

        const btn = document.createElement("button");
        btn.className = "btn btn-outline-success m-1";
        btn.textContent = hora;

        // Simulación: horas pares disponibles
        if (index % 2 === 0) {

            btn.addEventListener("click", () => {

                horaSeleccionada = hora;

                document.querySelectorAll("#horas-disponibles button")
                    .forEach(b => b.classList.remove("active"));

                btn.classList.add("active");

                mostrarCanchas();
            });

        } else {
            btn.classList.remove("btn-outline-success");
            btn.classList.add("btn-secondary");
            btn.disabled = true;
        }

        horasDisponibles.appendChild(btn);
    });
}
// MOSTRAR CANCHAS DISPONIBLES

function mostrarCanchas() {

    canchasDisponibles.innerHTML = "";

    if (!fechaSeleccionada || !horaSeleccionada) return;

    const ocupadas = reservas
        .filter(r => r.fecha === fechaSeleccionada && r.hora === horaSeleccionada)
        .map(r => r.cancha);

    const disponibles = todasLasCanchas.filter(c => !ocupadas.includes(c));

    if (disponibles.length === 0) {
        canchasDisponibles.innerHTML = `
            <div class="alert alert-danger mt-3">
                No hay canchas disponibles 😔
            </div>
        `;
        return;
    }

    disponibles.forEach(cancha => {

        const card = document.createElement("div");
        card.className = "card mt-3 shadow-sm";

        card.innerHTML = `
            <div class="card-body d-flex justify-content-between align-items-center">
                <span class="fw-bold">${cancha}</span>
                <button class="btn btn-success btn-sm">
                    Reservar
                </button>
            </div>
        `;

        card.querySelector("button").addEventListener("click", () => {
            alert(`Reservaste ${cancha} el ${fechaSeleccionada} a las ${horaSeleccionada}`);
        });

        canchasDisponibles.appendChild(card);
    });
}

// EVENTOS

selectYear.addEventListener("change", () => {
    generarCalendario(selectYear.value, selectMonth.value);
});

selectMonth.addEventListener("change", () => {
    generarCalendario(selectYear.value, selectMonth.value);
});

// INICIALIZACIÓN

llenarAnios();
llenarMeses();

const hoy = new Date();
selectYear.value = hoy.getFullYear();
selectMonth.value = hoy.getMonth();

generarCalendario(hoy.getFullYear(), hoy.getMonth());